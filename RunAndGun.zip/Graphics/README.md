pistol_pete graphic
source: https://en.wikipedia.org/wiki/Pistol_Pete_(Oklahoma_State_University)

defender_1 graphic
source: Hand drawing by Rachel O'Connor

running_back graphic
source http://clipart-library.com/clip-art/running-man-silhouette-18.htm

background_football_field.jpg 
source: http://clipart-library.com/clipart/n971605.htm