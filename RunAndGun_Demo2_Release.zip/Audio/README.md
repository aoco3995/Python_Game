Sources

battleThemeA.mp3 : https://opengameart.org/content/battle-theme-a
the_field_of_dreams.mp3 : https://opengameart.org/content/the-field-of-dreams
hit, pistol, dsplpain: http://www.wolfensteingoodies.com/archives/olddoom/music.htm