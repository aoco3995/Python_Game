pistol_pete graphic
source: https://en.wikipedia.org/wiki/Pistol_Pete_(Oklahoma_State_University)

defender_1 graphic
source: Hand drawing by Rachel O'Connor

running_back graphic
source http://clipart-library.com/clip-art/running-man-silhouette-18.htm

background_football_field.jpg 
source: http://clipart-library.com/clipart/n971605.htm

custom_football_field_background.png
Source: Drawn by Adam O'Connor

boone_pickens background 
source: https://www.pinterest.com/pin/744642119607703061/

gameover background
source: https://www.peakpx.com/en/hd-wallpaper-desktop-kvfkx
